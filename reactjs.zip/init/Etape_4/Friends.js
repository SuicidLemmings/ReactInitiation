import './Friends.css';
import React, {useState} from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import { TableFooter } from '@mui/material';
import MyTextField from './MyTextfield';
const friends = require('./InitiationHelper/friends.json');

function Friends() {
  const [rows, setRows] = useState(friends);
  const [infoForm] = useState({firstname: "", lastname: "", age: ""});

  const handleDelete = (index, e) => {
    setRows(rows.filter((item, idx) => {
      return idx !== index;
    }));
  };

  const handleAdd = (e) => {
    if (infoForm.firstname !== "" && infoForm.lastname !== "" && infoForm.age !== "" && Number(infoForm.age)) {
      var tmp = JSON.parse(JSON.stringify(rows));
      tmp.push({firstname: infoForm.firstname, lastname: infoForm.lastname, age: infoForm.age});
      setRows(tmp);
    }
  };

  return (
    <React.Fragment>
    <h1 className="center">Friends</h1>
    <div id="table">
      <TableContainer component={Paper} className="margined">
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="center">Firstname</TableCell>
              <TableCell align="center">Lastname</TableCell>
              <TableCell align="center">Age</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow
                key={index}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell align="center" component="th" scope="row">
                  {row.firstname}
                </TableCell>
                <TableCell align="center">{row.lastname}</TableCell>
                <TableCell align="center">{row.age}</TableCell>
                <TableCell align="center">
                  <Button variant="contained" color="error" onClick={handleDelete.bind(handleDelete, index)}>DEL</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TableCell align="center">
                <MyTextField label="Firstname" val={(value) => {infoForm.firstname = value}}/>
              </TableCell>
              <TableCell align="center">
                <MyTextField label="Lastname" val={(value) => {infoForm.lastname = value}}/>
              </TableCell>
              <TableCell align="center">
                <MyTextField label="Age" val={(value) => {infoForm.age = value}}/>
              </TableCell>
              <TableCell align="center">
                <Button variant="contained" color="info" onClick={handleAdd}>ADD</Button>
              </TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      </TableContainer>
    </div>
    </React.Fragment>
  );
}

export default Friends;
