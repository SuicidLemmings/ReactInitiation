import {useState, useEffect} from "react";

function useGetDateEverySeconds() {
    const [date, setDate] = useState(Date.now());

    useEffect(() => {
        window.setInterval(() => {
            setDate(Date.now());
        }, 1000);
    }, []);

    return date;
}

export {useGetDateEverySeconds};