import TextField from '@mui/material/TextField';
import {useState} from "react";

function MyTextField(props) {
    const [value, setValue] = useState("");

    const handleChange = (value) => {
        setValue(value.target.value);
        props.val(value.target.value);
    }

    return (
        <TextField value={value} onChange={handleChange} id="standard-basic" label={props.label} variant="standard" required />
    );
}

export default MyTextField;