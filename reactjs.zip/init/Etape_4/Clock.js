import './Clock.css';
import {useGetDateEverySeconds} from "./hooks/getDate";

function Clock() {
  const timestamp = useGetDateEverySeconds();
  const date = new Date(timestamp);
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  const hour = date.getUTCHours();
  const minutes = date.getUTCMinutes();
  const seconds = date.getUTCSeconds();

  const getNumberPaddedWithZero = (value) => {
    if (value < 10)
      return "0" + value;
    return value;
  };

  return (
    <div >
        {year}-{getNumberPaddedWithZero(month)}-{getNumberPaddedWithZero(day)}
        {" " + getNumberPaddedWithZero(hour)}:{getNumberPaddedWithZero(minutes)}:{getNumberPaddedWithZero(seconds)}
    </div>
  );
}

export default Clock;
