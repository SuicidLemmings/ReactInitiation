# INITIATION REACT JS

## Introducton

L'objectif de ce projet est de mettre la main à la pate afin de créer votre première application singlepage react JS. Pour ce projet, le repository actuel est déjà initialisé et contient toutes les sources nécessaires. L'objectif est cependant de créer un nouveau projet en entier et d'utiliser celui-ci comme référence en cas de problèmes ou d'incompréhension. La documentation suivante vous guidera à travers les différentes étapes vous permettant de créer cette application.

## Initialisation du projet:

Tout d'abord, installer **npm** si ce n'est pas déjà le cas. Pour ce faire, installer nvm. Suivez ce lien pour installer [NVM](https://github.com/nvm-sh/nvm). Une fois fait, lancer la commande d'installation de node
```
nvm install node
```
Vous pouvez voir votre version en cours d'utilisation en tapant
```
nvm list
```
Maintenant que vous avez npm ainsi qu'une version de node, créez le projet react via la commande
```
npx create-react-app $nom_projet
```
Votre projet react est maintenant initialisé ! Vous pouvez l'essayer en tapant
```
npm start
```
Une page devrait s'ouvrir avec votre projet. Maintenant nous allons passer au développement du projet. Si vous avez des doutes concernant l'architecture du projet et comment ce dernier fonctionne, revoyez le Powerpoint accompagnant ce projet. Nous vous conseillons dans tous les cas de l'avoir à portée de main afin de répondre à toutes les questions que vous pourriez avoir lors de votre développement.

## Etapes:

Pour chaque étape, un fichier nommé `Etape_${numero-etape}` contient les sources de l'étape. Afin de voir le résultat attendu de chaque étape, remplacez le dossier `src` actuel par ce dossier et lancez
```
npm start
```
**Ne vous réferrez au code sorce qu'en cas de nécessité, le but est de d'essayer de développer votre application.**

### Etape 1:

Création d'un composant qui affiche l'heure.

L'objectif de cette première étape est de mettre en place un composant sous forme de hook qui permettra de voir l'heure. Basez vous sur l'exemple du powerpoint afin de mettre en place ce composant à la place du composant `App.js` déjà existant. Vous pouvez utiliser un seul hook (le composant), ou bien deux afin d'extraire la logique applicative de la récupération de l'heure.

### Etape 2:

A la suite du composant date, créez un composant utilisateur qui affiche le nom et le prénom de l'utilisateur courant. L'utilisateur à afficher peut etre trouvé dans le dossier `src/InitiationHelper/user` sous forme de fichier `json`. Importez le fichier et utilisez le pour afficher les informations.

### Etape 3:

Création d'un tableau qui affiche les informations des amis de l'utilisateur. Le tableau d'utlisateur à afficher peut etre trouvé dans dans le dossier `src/InitiationHelper/friends.json`. Afin de créer un tableau, certaines bibliothèques existent pour nous faciliter la tache. Nous allons pour ça utiliser notre première librairie externe. Le nom de la librairie est [material react ui](https://mui.com/). Installez la bibliothèque via npm et utilisez un composant [table](https://mui.com/components/tables/) dans votre code afin d'afficher les amis sous la forme d'un tableau.

### Etape 4:

Mettre en place la possibilité d'ajouter et supprimer un ami du tableau. Pour cela, utilisez des boutons. Vous pouvez par exemple, utiliser un formulaire afin de renseigner les champs à compléter pour ajouter un utilisateur et mettre un bouton `supprimer` dans une colonne pour de chaque utilisateur du tableau.

### Etape 5:

Utilisez le [react routeur](https://reactrouter.com/docs/en/v6) pour créer une application avec différentes pages et gérer les urls. Additionellement, mettez la date (Etape 1) dans un header qui sera **ré-utilisé par toutes les pages**. En plus de ce bandeau, faites deux pages: une page pour afficher l'utilisateur courant (Etape 2), et une page pour afficher le tableau d'amis (Etape 3 et 4). Dans le bandeau de ajouter un système de navigation. Pour cela, ajoutez deux liens, chacun permettant d'aller sur une des deux pages.

## Bonus:
- Utilisez [SCSS](https://fr.wikipedia.org/wiki/Sass_(langage)) au lieu du CSS
- Mettre en place la gestion du thème et de la langue.
- Connectez vous à une API REST avec `react_query`
- Utilisez les cookies et le session storage (au besoin) pour stocker les informations renvoyées par le serveur tel que le token d'authentification.
- Mise en place de guards d'authentification et de roles (au niveau du router) permettant de restreindre l'accès à certaines pages.