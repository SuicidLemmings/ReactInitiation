import "./PageWrapper.css";
import {Link} from "react-router-dom";
import Clock from './Clock';

function PageWrapper() {
  return (
    <div id="header">
      <img src="/ais_logo_2012.png" alt="Groupe AIS logo" id="logo"></img>
      <Link className="link" to="/user">User</Link>
      <Link className="link" to="/friends">Friends</Link>
      <div id="clock">
        <Clock/>
      </div>
    </div>
  );
}

export default PageWrapper;
