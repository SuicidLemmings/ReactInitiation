import './User.css';
const UserData = require('./InitiationHelper/user.json');

function User() {
  return (
    <div id="user-section">
      <h1>Account</h1>
      <div>
        <p className="underline inline">FirstName:</p>{' '}
        <p className="inline">{UserData.firstname}</p>
      </div>
      <div>
        <p className="underline inline">LastName:</p>{' '}
        <p className="inline">{UserData.lastname}</p>
      </div>
      <div>
        <p className="underline inline">Age:</p>{' '}
        <p className="inline">{UserData.age}</p>
      </div>
    </div>
  );
}

export default User;
